import test from 'node:test';
import assert from 'node:assert/strict';
import {renderChatTable, renderComment, renderReviewSummary, validateReviewInput} from '../scripts/lib/requirements/review.mjs';
import {fingerprint} from '../scripts/lib/execution-core/data.mjs';
import {chatInput} from './fixtures/requirements.mjs';

const reportedId = 'req-70d3b394275978d0a3db7e54b2d900711ed8cb8bf61fc67d';
function displayFixture() {
  const attachment = 'ado-attachment-12345678-1234-1234-1234-123456789012';
  const parts = [
    {sourceId: 'story', location: 'System.Title', kind: 'context', text: 'Manage saved addresses'},
    {sourceId: 'story', location: 'System.Description', kind: 'requirement', text: 'Save the address.'},
    {sourceId: 'story', location: 'Microsoft.VSTS.Common.AcceptanceCriteria', kind: 'criterion', text: 'Allow three addresses.'},
    {sourceId: 'discussion', location: 'comment:17', kind: 'discussion', text: 'Which address formats are supported?'},
    {sourceId: attachment, location: 'page 2 paragraph 1', kind: 'requirement', text: 'Allow five addresses.'},
    {sourceId: 'notes-machine-ref', location: 'lines 2-3', kind: 'requirement', text: 'Show the saved name.'}
  ].map((part, index) => ({...part, id: fingerprint({index}), revision: 'a'.repeat(64)}));
  const source = {origin: {storyId: 200}, request: {sources: [{id: 'notes-machine-ref', path: 'notes/requirements & limits.md', kind: 'file'}]}, revisions: [{id: attachment, name: 'rules & limits.pdf'}], parts};
  const inventory = parts.map(part => ({id: 'req-' + part.id.slice(0, 24), partId: part.id, start: 0, end: part.text.length}));
  const state = {consumer: 'consumer', snapshot: 'snapshot', head: 'head', inventory};
  const findings = parts.map((part, index) => ({id: 'F-0' + (index + 1), type: 'Gap', severity: 'Medium', finding: 'Clarify supported behavior', sources: [{requirementId: inventory[index].id, quote: part.text}], question: 'Which outcome is accepted?'}));
  return {source, state, draft: {findings, comment: null, mentions: []}};
}

test('chat and posted table use bold readable source labels with plain exact quotes and no internal provenance', () => {
  const f = displayFixture(), before = structuredClone(f), table = renderChatTable(f.draft, f.state, f.source), comment = renderComment(f.draft, f.state, f.source, []);
  for (const output of [table, comment.text, comment.html]) {
    for (const label of ['Title:', 'Description:', 'Acceptance Criteria:', 'Discussion comment 17:', 'rules &amp; limits.pdf', 'requirements &amp; limits.md', 'page 2 paragraph 1', 'lines 2-3']) assert(output.includes(label), label);
    for (const internal of ['System.Title', 'System.Description', 'Microsoft.VSTS.Common.AcceptanceCriteria', 'story /', 'notes-machine-ref', 'ado-attachment-', 'comment:17', 'revision', 'a'.repeat(64), ...f.state.inventory.map(item => item.id)]) assert(!output.includes(internal), internal);
  }
  for (const label of ['Title', 'Description', 'Acceptance Criteria', 'Discussion comment 17', 'Attachment: rules &amp; limits.pdf (page 2 paragraph 1)', 'File: requirements &amp; limits.md (lines 2-3)']) {
    assert(table.includes(`**${label}:**`), label); assert(comment.html.includes(`<strong>${label}:</strong>`), label);
  }
  for (const part of f.source.parts) assert(comment.html.includes(`</strong> “${part.text}”`));
  assert.deepEqual(f, before); assert.match(table, /F-01: Clarify/);
});

test('attachment provenance remains readable when an old snapshot lacks a filename', () => {
  const f = displayFixture(); f.source.revisions = [];
  const output = renderChatTable(f.draft, f.state, f.source);
  assert.match(output, /Attachment.*page 2 paragraph 1/); assert(!output.includes('ado-attachment-'));
});

test('generated finding IDs stay internal while readable labels and stored references remain intact', () => {
  const f = displayFixture(); f.draft.findings[0].id = reportedId;
  const before = structuredClone(f);
  for (const output of [renderChatTable(f.draft, f.state, f.source), renderReviewSummary(f.draft)]) assert(!output.includes(reportedId));
  const draft = validateReviewInput(chatInput(f.state, f.draft.findings), f.state, f.source), comment = renderComment(draft, f.state, f.source, []);
  for (const output of [comment.text, comment.html]) {assert(!output.includes(reportedId)); assert(output.includes('F-02: Clarify'));}
  assert(comment.text.includes('**Clarify supported behavior**')); assert(!comment.text.includes('First priority:'));
  assert.equal(draft.findings[0].id, reportedId); assert.deepEqual(f, before);
});

test('free-form findings, questions, manual comments and source quotes retain technical wording without scanning', () => {
  const f = displayFixture(), quote = 'System.Description'; f.source.parts[0].text = quote; f.state.inventory[0].end = quote.length;
  const finding = {...f.draft.findings[0], finding: 'Discuss ' + reportedId, question: 'Clarify Microsoft.VSTS.Common.AcceptanceCriteria.', sources: [{requirementId: f.state.inventory[0].id, quote}]};
  const text = `See _${reportedId}_ and System.Description <current>.`;
  const draft = validateReviewInput(chatInput(f.state, [finding], {comment: text}), f.state, f.source), comment = renderComment(draft, f.state, f.source, []);
  assert.deepEqual(draft.findings, [finding]); assert.equal(draft.comment, text);
  assert(comment.text.includes('&lt;current&gt;')); assert(!comment.text.includes(`<current>`)); assert(comment.text.includes('\\_req\\-'));
  assert(comment.html.includes(`See _${reportedId}_ and System.Description &lt;current&gt;.`));
  assert(renderChatTable(draft, f.state, f.source).includes('**Title:** “System.Description”'));
});

test('emphasis uses bold titles, named severity dots and only the selected question phrase in chat and ADO', () => {
  const f = displayFixture(); f.draft.findings = f.draft.findings.slice(0, 3);
  for (const [index, severity] of ['High', 'Medium', 'Low'].entries()) Object.assign(f.draft.findings[index], {severity, question: 'What is the maximum retry count?', questionFocus: 'maximum retry count'});
  const before = structuredClone(f), table = renderChatTable(f.draft, f.state, f.source), comment = renderComment(f.draft, f.state, f.source, []);
  assert.match(table, /\| \*\*F-01: Clarify supported behavior\*\* \| Gap \| \*\*🔴 High\*\*/);
  for (const severity of ['🟠 Medium', '🔵 Low']) assert(table.includes(`**${severity}**`));
  assert(table.includes('What is the **maximum retry count**?')); assert(!table.includes('**What is the'));
  assert(comment.html.includes('<td><strong>F-01: Clarify supported behavior</strong></td><td>Gap</td><td><strong>🔴 High</strong></td>'));
  assert(comment.html.includes('What is the <strong>maximum retry count</strong>?'));
  assert(comment.html.includes('<p><strong>Summary: 3 findings — 3 gaps, 0 contradictions</strong><br>🔴 <strong>High: 1</strong>'));
  assert(comment.html.includes('<td><strong>Title:</strong> “Manage saved addresses”</td>')); assert(!/style=|<font|background|<span/.test(comment.html));
  assert.deepEqual(f, before);
});

test('emphasis escapes literal markup before wrapping focus text and keeps manual bodies verbatim', () => {
  const f = displayFixture(), finding = f.draft.findings[0];
  Object.assign(finding, {finding: '<strong>literal</strong> **words**', question: 'Does <Admin> & **literal** apply?', questionFocus: '<Admin> & **literal**'});
  const draft = validateReviewInput(chatInput(f.state, [finding]), f.state, f.source), comment = renderComment(draft, f.state, f.source, []);
  assert(comment.text.includes('Does **&lt;Admin&gt; &amp; \\*\\*literal\\*\\*** apply?'));
  assert(comment.html.includes('Does <strong>&lt;Admin&gt; &amp; **literal**</strong> apply?'));
  assert(!comment.html.includes('<Admin>')); assert(!comment.html.includes('<strong>literal</strong>'));
  const manual = renderComment({...draft, comment: 'Keep **my** <manual> wording.'}, f.state, f.source, []);
  assert(manual.text.endsWith('Keep \\*\\*my\\*\\* &lt;manual&gt; wording\\.')); assert(manual.html.endsWith('<p>Keep **my** &lt;manual&gt; wording.</p>'));
});

test('manual Markdown preview stays literal with multiline whitespace while stored wording and outgoing HTML remain unchanged', () => {
  const f = displayFixture(), raw = '    <Admin> **literal**\n# Heading\n\n1. [link](target) ~~draft~~';
  const draft = {...f.draft, comment: raw}, before = structuredClone(draft), comment = renderComment(draft, f.state, f.source, []);
  assert(!comment.text.includes('<Admin>')); assert(!comment.text.includes('**literal**')); assert(!comment.text.includes('\n# Heading'));
  assert(comment.text.includes('&#32;&#32;&#32;&#32;&lt;Admin&gt; \\*\\*literal\\*\\*\\\n\\# Heading'));
  assert(comment.text.endsWith('1\\. \\[link\\]\\(target\\) \\~\\~draft\\~\\~'));
  assert(comment.html.endsWith('<p>    &lt;Admin&gt; **literal**<br># Heading<br><br>1. [link](target) ~~draft~~</p>'));
  assert.deepEqual(draft, before);
});

test('terminal manual newlines do not expose a Markdown hard-break marker', () => {
  const f = displayFixture(), raw = 'Keep literal.\r\n\r\n', draft = {...f.draft, comment: raw};
  const comment = renderComment(draft, f.state, f.source, []);
  assert(comment.text.endsWith('Keep literal\\.\\\n\\\n&#32;'));
  assert(comment.html.endsWith('<p>Keep literal.<br><br></p>')); assert.equal(draft.comment, raw);
});

test('manual URL wording cannot become GFM links or expose escaped punctuation', () => {
  const f = displayFixture(), raw = 'https://example.test/a?x=1&y=2\nhttp://localhost/path\n<https://example.test/path>\nwww.example.test';
  const draft = {...f.draft, comment: raw}, comment = renderComment(draft, f.state, f.source, []);
  assert(comment.text.endsWith('https\\://example\\.test/a?x\\=1&amp;y\\=2\\\nhttp\\://localhost/path\\\n&lt;https\\://example\\.test/path&gt;\\\nwww\\.example\\.test'));
  assert(comment.html.endsWith('<p>https://example.test/a?x=1&amp;y=2<br>http://localhost/path<br>&lt;https://example.test/path&gt;<br>www.example.test</p>'));
  assert.equal(draft.comment, raw);
});

test('manual setext underline wording cannot become a Markdown heading', () => {
  const f = displayFixture(), raw = 'Keep literal\n===', draft = {...f.draft, comment: raw};
  const comment = renderComment(draft, f.state, f.source, []);
  assert(comment.text.endsWith('Keep literal\\\n\\=\\=\\='));
  assert(comment.html.endsWith('<p>Keep literal<br>===</p>')); assert.equal(draft.comment, raw);
});

test('Markdown emphasis preserves punctuation, adjacent focus matches and title whitespace', () => {
  const f = displayFixture(), finding = {...f.draft.findings[0], finding: 'Retry policy '};
  for (const [question, questionFocus, markdown, html] of [
    ['Use ABAB?', 'AB', 'Use **ABAB**?', 'Use <strong>ABAB</strong>?'],
    ['Test ** x?', '*', 'Test **\\*\\*** x?', 'Test <strong>**</strong> x?'],
    ['Use C++ rules?', '++', 'Use C++ rules?', 'Use C++ rules?'],
    ['Use ++C rules?', '++', 'Use ++C rules?', 'Use ++C rules?'],
    ['😀*?', '*', '😀\\*?', '😀*?'],
    ['😀x', '😀', '😀x', '😀x'],
    ['*😀', '*', '\\*😀', '*😀'],
    ['€++', '++', '€**++**', '€<strong>++</strong>'],
    ['Does **retry count** apply?', 'retry count', 'Does \\*\\***retry count**\\*\\* apply?', 'Does **<strong>retry count</strong>** apply?']
  ]) {
    const draft = {...f.draft, findings: [{...finding, question, questionFocus}]}, comment = renderComment(draft, f.state, f.source, []);
    assert(comment.text.includes(` | ${markdown} |`), question);
    assert(comment.html.includes(`<td>${html}</td>`), question);
    assert(comment.text.includes('| **F-01: Retry policy**  |'));
    assert.equal(draft.findings[0].finding, 'Retry policy '); assert.equal(draft.findings[0].question, question);
  }
});

test('two-line chat summary has one hard break and no First priority concern', () => {
  const f = displayFixture(), summary = renderReviewSummary(f.draft);
  assert.equal(summary.split('\\\n').length, 2); assert(!summary.includes('First priority')); assert(!summary.includes('Clarify supported behavior'));
});

test('GFM strikethrough markers stay literal in generated source quotes and focused questions', () => {
  const f = displayFixture(), quote = '~~literal~~', finding = f.draft.findings[0];
  f.source.parts[0].text = quote; f.state.inventory[0].end = quote.length;
  Object.assign(finding, {finding: 'Keep ~~title~~ literal', sources: [{requirementId: f.state.inventory[0].id, quote}], question: 'Does ~~literal~~ apply?', questionFocus: 'literal'});
  const comment = renderComment({...f.draft, findings: [finding]}, f.state, f.source, []);
  assert(comment.text.includes('**Title:** “\\~\\~literal\\~\\~”'));
  assert(comment.text.includes('Does \\~\\~**literal**\\~\\~ apply?'));
  assert(comment.text.includes('**F-01: Keep \\~\\~title\\~\\~ literal**'));
  assert(comment.html.includes('<td><strong>Title:</strong> “~~literal~~”</td>'));
  assert(comment.html.includes('Does ~~<strong>literal</strong>~~ apply?'));
  assert(comment.html.includes('<strong>F-01: Keep ~~title~~ literal</strong>'));
  assert.equal(finding.sources[0].quote, quote);
});
