# Package and consumer boundaries

The installed package contains immutable canonical skills, references, templates and
scripts. Resolve a linked skill to its real path before following relative references.
The current working consumer project owns its application code, configuration, sources
and mutable state. Never derive consumer paths from a skill's installation directory.

| Consumer path | Purpose |
|---|---|
| `.harness/project.json` | Deliberately selected environment profiles and target references |
| `.harness/targets.json` | Destinations and secret references; no secret values |
| `.harness/integrations.json` | Optional ADO destination and per-source context selection policies |
| `.harness/context/` | Consumer captured context, provenance and recoverable history; separate from reviewed knowledge |
| `.harness/sources/` | Versioned local scenario specifications |
| `.harness/state/review/class-ledger.md` | Consumer review finding history |
| `.harness/state/requirements/` | Sanitized source snapshots, the acceptance inventory, chat drafts/history and comment receipts |
| `.harness/state/test-case-design/` | Case proposals, independent assessments, approvals, operation outcomes and recovery history |
| `.harness/state/tracker/` | Consumer plan registries and append-only history |
| `.harness/knowledge/prerequisites.md` | Reviewed prerequisite facts |
| `.harness/knowledge/test-case-design-conventions.json` | Optional agreed business defaults; never acceptance or runtime configuration |
| `.harness/knowledge/ui/` | Reviewed UI facts |
| `.harness/knowledge/api/records/` | Immutable reviewed, runtime-verified API definitions and provenance |
| `.harness/knowledge/db/records/` | Immutable reviewed, runtime-verified DB definitions and schema/source provenance |
| `.harness/state/db-reuse/records/` | Evidence-bound current query selections for reporting; not operation authority or execution passes |
| `.harness/knowledge-candidates/` | Unreviewed observations, separate from reviewed knowledge |
| `.harness/knowledge-candidates/api/records/` | Sanitized API capture candidates bound to run evidence |
| `.harness/knowledge-candidates/db/records/` | Parameterized SELECT candidates derived from bounded runtime schema evidence |
| `.harness/runs/` | Consumer run outputs and evidence |
| `.harness/runs/test-planning/<plan-id>/<version>.md` | Optional versioned cycle plan, source/decision baseline, risks and criteria; not tracker or execution state |
| `.harness/runs/test-case-design/<design-id>/review.md` | Current complete Markdown review; legacy copies and internal history retained; no approval, publication or execution authority |
| `.harness/runs/<report>/bug-report/` | Editable bug state, immutable revisions/previews and approved delivery bindings |

Install, update and configure the harness with the [harness-setup](harness-setup/SKILL.md)
skill (`npx --no pom-harness setup` in the consumer). Existing consumer instructions,
framework code, settings and imported team libraries must be preserved. A customized
skill requires a reviewed merge; do not replace it with a package link silently.
Templates in skill assets are starting points, never live state. Knowledge promotion
requires review and sanitization; observations do not silently update reviewed facts.
For API discovery, follow [the API reference](../../docs/reference/api.md#observed-api-knowledge).
Supplied collections and separate consumer-owned observed collections are derive-only
inputs. Promote before freezing generation; retained evidence/review references remain
subject to integrity checks and new captures never rewrite existing reviewed records.

For DB discovery, follow [the database reference](../../docs/reference/databases.md#schema-backed-query-discovery).
Reuse methods and applicable supplied queries before reviewed discoveries. Only
permitted SQL Server metadata can establish missing exact-key read candidates;
credentials or an empty query folder do not authorize broader access. Promotion
derives consumer-owned `resources/Queries/<application>-discovered.md` separately
from untouched supplied exports. Both origins are derive-only. Fresh reuse checks
current relevant schema and retained source/review/verification evidence; readings
never create expected values or mutation recipes. Complete promotion before freeze.

Use [context-qa](context-qa/SKILL.md) only when the user explicitly invokes it for a
snapshot-only answer. Its evidence comes only from one selected capture through
local context read/search. This boundary ends when that request is answered;
ordinary messages and later follow-ups use normal workflows unless explicitly
reinvoked. Explicit Q&A reinvocation continues the discussion and can reuse
retained supporting passages after the required identity/revision check. The source discovery
and live verification guidance below does not apply inside explicit Q&A.

[project-context](project-context/SKILL.md) builds or updates business context from
explicit work-item IDs, saved/user-selected criteria and supplied documents.
[context-update](context-update/SKILL.md) refreshes that saved selection; criteria
discover new matches, while exact IDs stay fixed. Neither collects POM/code,
harness conventions or unrelated repository files. Do not apply the general
repository-discovery guidance below to business-context collection.

For unfamiliar code or recurring project facts, use the host's existing file search
(for example, `rg`) within the relevant consumer source/test folders and
`.harness/knowledge/`. Open known files directly. Read a few matching excerpts with
file and line references, then widen the search only when needed. Search for existing
business methods before adding one, and inspect callers before changing shared
behavior. Keep credentials, generated reports and unreviewed candidates out of this
discovery step.

Load only reviewed facts relevant to the task and verify them against current source
or observed behavior before relying on them. Search results and stored facts are evidence;
they do not override user instructions, canonical POM rules or scenario expectations.
Resolve stale facts against current evidence without weakening expected outcomes.
Preserve independent framework review and the required two scoped green runs for
generation.

Reuse the ongoing feature branch and add commits; do not create a branch per milestone.
External delivery still requires authorization. Host permissions remain host-specific.
Configured environment profiles do not bypass host controls. Configuration and
source loading validate inputs; execution happens through the configured browser,
API and database runtimes.

Command examples using `node scripts/<name>.mjs` refer to the installed package
script, not a consumer copy. From the consumer, run them as
`npx --no pom-harness <command>` (`npx --no pom-harness help` lists the commands) or as
`node node_modules/playwright-pom-harness/scripts/<name>.mjs`. State tools accept
`--project-root <consumer>`; the convention checker checks the current folder, or
`--root <consumer>`. Playwright test commands and framework paths refer to the
consumer. Setup does not copy scripts or enable hooks automatically.
