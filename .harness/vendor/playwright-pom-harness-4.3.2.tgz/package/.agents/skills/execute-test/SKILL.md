---
name: execute-test
description: Execute an ADO suite or story through live browser, API and database runtimes, without generating automation code. Produce verified reports and optionally file bugs or publish suite outcomes.
---

# Execute manual tests

Resolve [ROOTS](../ROOTS.md) first. Run the consumer's installed CLI with
`npx --no pom-harness execute`; use [automate-test](../automate-test/SKILL.md)
when the request includes durable POM code generation.
Use [maintain-test](../maintain-test/SKILL.md) to investigate prior failures or
reassess blocked cases before resuming this execution workflow.

Accept `/execute-test suite <id> [plan <id>] [on <environment>] [checkpoint]`
or `/execute-test story <id> [on <environment>]`. Execute sequentially, pausing
on blockers. In checkpoint mode, pause after each case. Authorization already
given by the user remains in force for ordinary permitted application operations.

Published [test-case-design](../test-case-design/SKILL.md) cases enter through these
existing ADO routes. Preserve preparation, explicit inputs/variations, all ordered
actions and expected results, and cleanup through parsing/refinement. Publication
and design review are not execution evidence; missing business details need
source-backed clarification before the affected case can execute.

Browser steps passively save sanitized API candidates and `api-discovery.json`
through the shared runtime. Follow [observed API knowledge](../../../docs/reference/api.md#observed-api-knowledge):
reuse business methods and applicable supplied collections first, then reviewed,
runtime-verified discoveries for missing operations. Report relevant discoveries,
unresolved gaps and any separately promoted observed collection without changing
case verdicts or generating POM code. Capture alone never promotes reviewed knowledge,
invents cleanup/authentication, or makes a collection a prerequisite.

For missing DB lookup/verification operations, follow
[schema-backed discovery](../../../docs/reference/databases.md#schema-backed-query-discovery)
during refinement, before freeze. Reuse methods and applicable supplied queries
first, then current reviewed knowledge. An empty folder does not block permitted
SQL Server metadata discovery. Retain sanitized candidates, review business
semantics, verify matching operations through the configured runtime, and promote
the separate consumer-owned discovered document. Fresh reuse requires current
schema and intact supporting evidence. This route generates no POM code, adds no
per-query approval ceremony and never invents required mutation recipes. Missing
metadata/identity/semantics or cleanup remains a case gap. Return to refinement
instead of mutating a frozen step; report saved paths separately from verdicts.

1. Run `prepare suite|story <id> [--plan <id>] [--environment <name>] [--checkpoint]`.
   Read the captured source and exclusions. Edit only its draft `refinement.json`,
   following [refinement](references/refinement.md); then run `freeze <exec>`.
   Complete required login, API/DB operations, provenance and cleanup declarations.
   Resolve `readiness.ready: false` for the selected scenario before starting it.
2. Read [protocol](references/protocol.md) and [verdicts](references/verdicts.md).
   Run `next <exec>` and drive its live commands. Adapt to the observed UI using
   fresh refs. Every expected condition needs a check, grounded observation or
   explicit unresolved reason. Actions alone do not establish a pass.
   Use the returned `startUrl` and pause between cases when `checkpoint` is true.
3. Repeat `next` until complete. Use `resume` or `next --rerun <scenario>` after
   an interruption or integrity failure. Report remaining blockers candidly.
4. Always run `report <exec>` before the final response, including failed, blocked,
   interrupted or partially completed work. A captured source can be reported before
   freeze. For blockers not already recorded by execution/readiness, supply source-bound
   notes with `report <exec> --input <consumer-notes.json>` following
   [reporting](../../../docs/reporting.md#case-results-and-blocker-notes).
   Link the returned `html` directly and summarize case counts, failure/blocker reasons
   and next actions. Include the report in a related PR
   when PR delivery is part of the work, following the
   [report handoff](../../../docs/reporting.md#skill-report-handoff).
   Share this single case report with its Summary and Defects companions. Keep the
   HTML focused on outcomes, expected/actual results, reasons, actions and screenshots;
   raw records, internal IDs, hashes and debugging metadata stay in execution storage.
   If report delivery fails, state that separately from case outcomes. Report output is ignored consumer storage; never generate
   framework, tracker or legacy verification files on this route.
5. Before finishing failed, blocked or partial execution, perform the
   [post-run bug review](../../../docs/bug-reporting.md#post-run-review) through
   [bug-report](../bug-report/SKILL.md), without waiting for another invocation.
   Classify every finding, prepare editable drafts for supported application
   defects, and group related occurrences only with an evidence-backed reason.
   Present complete drafts and remaining investigation/repair items for edits,
   selection or deferral. Reuse verified run evidence. Drafting does not
   authorize filing or additional reproduction.
   Read [delivery](references/delivery.md) only when ADO delivery is requested.
   Preview first. External writes require `--execute`; the request must authorize
   the concrete delivery. Story scope supports bugs only.
